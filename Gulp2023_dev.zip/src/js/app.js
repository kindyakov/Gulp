import checkSupportWebP from "./modules/checkSupportWebP.js"

checkSupportWebP()