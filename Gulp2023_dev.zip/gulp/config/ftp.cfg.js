const configFTP = {
  host: '', // Адрей сервера
  user: '', // Имя пользователя
  password: '', // Пароль
  parallel: 3 // Кол-во потоков
}
export default configFTP